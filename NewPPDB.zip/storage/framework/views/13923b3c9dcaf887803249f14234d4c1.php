<?php $__env->startSection('content'); ?>

<div class="page-inner">
    <div
      class="d-flex align-items-left align-items-md-center flex-column flex-md-row pt-2 pb-4"
    >
      <div>
        <h3 class="fw-bold mb-3">Dashboard</h3>
      </div>

    </div>
    <div class="row row-card-no-pd">
      <div class="col-12 col-sm-6 col-md-6 col-xl-3">
        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between">
              <div>
                <h6><b>Total Pendaftar</b></h6>
                <p class="text-muted">Mahasiswa</p>
              </div>
              <h4 class="text-info fw-bold"><?php echo e($totalUser); ?></h4>
            </div>
            <div class="progress progress-sm">
              <div
                class="progress-bar bg-info w-100"
                role="progressbar"
                aria-valuenow="100"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>

          </div>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-6 col-xl-3">
        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between">
              <div>
                <h6><b>Total Lolos</b></h6>
                <p class="text-muted">Mahasiswa</p>
              </div>
              <h4 class="text-success fw-bold"><?php echo e($userDiterima); ?></h4>
            </div>
            <div class="progress progress-sm">
              <div
                class="progress-bar bg-success w-100"
                role="progressbar"
                aria-valuenow="100"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-6 col-xl-3">
        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between">
              <div>
                <h6><b>Total Ditolak</b></h6>
                <p class="text-muted">Mahasiswa</p>
              </div>
              <h4 class="text-danger fw-bold"><?php echo e($userDitolak); ?></h4>
            </div>
            <div class="progress progress-sm">
              <div
                class="progress-bar bg-danger w-100"
                role="progressbar"
                aria-valuenow="100"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-12 col-sm-6 col-md-6 col-xl-3">
        <div class="card">
          <div class="card-body">
            <div class="d-flex justify-content-between">
              <div>
                <h6><b>Dalam Proses</b></h6>
                <p class="text-muted">Mahasiswa</p>
              </div>
              <h4 class="text-secondary fw-bold"><?php echo e($userProses); ?></h4>
            </div>
            <div class="progress progress-sm">
              <div
                class="progress-bar bg-secondary w-100"
                role="progressbar"
                aria-valuenow="100"
                aria-valuemin="0"
                aria-valuemax="100"
              ></div>
            </div>
          </div>
        </div>
      </div>
    </div>

    
    <!-- <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body pb-0">
                            <div class="h1 fw-bold float-end text-primary">+5%</div>
                            <h2 class="mb-2">17</h2>
                            <p class="text-muted">Users online</p>
                            <div class="pull-in sparkline-fix">
                                <div id="lineChart"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body pb-0">
                            <div class="h1 fw-bold float-end text-danger">-3%</div>
                            <h2 class="mb-2">27</h2>
                            <p class="text-muted">New Users</p>
                            <div class="pull-in sparkline-fix">
                                <div id="lineChart2"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body pb-0">
                            <div class="h1 fw-bold float-end text-warning">+7%</div>
                            <h2 class="mb-2">213</h2>
                            <p class="text-muted">Transactions</p>
                            <div class="pull-in sparkline-fix">
                                <div id="lineChart3"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
    <!-- <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-title">Top Products</div>
                        </div>
                        <div class="card-body pb-0">
                            <div class="d-flex">
                                <div class="avatar">
                                    <img src="assets/img/logoproduct.svg" alt="..." class="avatar-img rounded-circle">
                                </div>
                                <div class="flex-1 pt-1 ms-2">
                                    <h6 class="fw-bold mb-1">CSS</h6>
                                    <small class="text-muted">Cascading Style Sheets</small>
                                </div>
                                <div class="d-flex ms-auto align-items-center">
                                    <h4 class="text-info fw-bold">+$17</h4>
                                </div>
                            </div>
                            <div class="separator-dashed"></div>
                            <div class="d-flex">
                                <div class="avatar">
                                    <img src="assets/img/logoproduct.svg" alt="..." class="avatar-img rounded-circle">
                                </div>
                                <div class="flex-1 pt-1 ms-2">
                                    <h6 class="fw-bold mb-1">J.CO Donuts</h6>
                                    <small class="text-muted">The Best Donuts</small>
                                </div>
                                <div class="d-flex ms-auto align-items-center">
                                    <h4 class="text-info fw-bold">+$300</h4>
                                </div>
                            </div>
                            <div class="separator-dashed"></div>
                            <div class="d-flex">
                                <div class="avatar">
                                    <img src="assets/img/logoproduct3.svg" alt="..." class="avatar-img rounded-circle">
                                </div>
                                <div class="flex-1 pt-1 ms-2">
                                    <h6 class="fw-bold mb-1">Ready Pro</h6>
                                    <small class="text-muted">Bootstrap 5 Admin Dashboard</small>
                                </div>
                                <div class="d-flex ms-auto align-items-center">
                                    <h4 class="text-info fw-bold">+$350</h4>
                                </div>
                            </div>
                            <div class="separator-dashed"></div>
                            <div class="pull-in">
                                <canvas id="topProductsChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <div class="card-title fw-mediumbold">Suggested People</div>
                            <div class="card-list">
                                <div class="item-list">
                                    <div class="avatar">
                                        <img src="assets/img/jm_denis.jpg" alt="..." class="avatar-img rounded-circle">
                                    </div>
                                    <div class="info-user ms-3">
                                        <div class="username">Jimmy Denis</div>
                                        <div class="status">Graphic Designer</div>
                                    </div>
                                    <button class="btn btn-icon btn-primary btn-round btn-xs">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                </div>
                                <div class="item-list">
                                    <div class="avatar">
                                        <img src="assets/img/chadengle.jpg" alt="..." class="avatar-img rounded-circle">
                                    </div>
                                    <div class="info-user ms-3">
                                        <div class="username">Chad</div>
                                        <div class="status">CEO Zeleaf</div>
                                    </div>
                                    <button class="btn btn-icon btn-primary btn-round btn-xs">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                </div>
                                <div class="item-list">
                                    <div class="avatar">
                                        <img src="assets/img/talha.jpg" alt="..." class="avatar-img rounded-circle">
                                    </div>
                                    <div class="info-user ms-3">
                                        <div class="username">Talha</div>
                                        <div class="status">Front End Designer</div>
                                    </div>
                                    <button class="btn btn-icon btn-primary btn-round btn-xs">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                </div>
                                <div class="item-list">
                                    <div class="avatar">
                                        <img src="assets/img/mlane.jpg" alt="..." class="avatar-img rounded-circle">
                                    </div>
                                    <div class="info-user ms-3">
                                        <div class="username">John Doe</div>
                                        <div class="status">Back End Developer</div>
                                    </div>
                                    <button class="btn btn-icon btn-primary btn-round btn-xs">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                </div>
                                <div class="item-list">
                                    <div class="avatar">
                                        <img src="assets/img/talha.jpg" alt="..." class="avatar-img rounded-circle">
                                    </div>
                                    <div class="info-user ms-3">
                                        <div class="username">Talha</div>
                                        <div class="status">Front End Designer</div>
                                    </div>
                                    <button class="btn btn-icon btn-primary btn-round btn-xs">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                </div>
                                <div class="item-list">
                                    <div class="avatar">
                                        <img src="assets/img/jm_denis.jpg" alt="..." class="avatar-img rounded-circle">
                                    </div>
                                    <div class="info-user ms-3">
                                        <div class="username">Jimmy Denis</div>
                                        <div class="status">Graphic Designer</div>
                                    </div>
                                    <button class="btn btn-icon btn-primary btn-round btn-xs">
                                        <i class="fa fa-plus"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-primary bg-primary-gradient">
                        <div class="card-body">
                            <h5 class="mt-3 b-b1 pb-2 mb-4 fw-bold">Active user right now</h5>
                            <h1 class="mb-4 fw-bold">17</h1>
                            <h5 class="mt-3 b-b1 pb-2 mb-5 fw-bold">Page view per minutes</h5>
                            <div id="activeUsersChart"></div>
                            <h5 class="mt-5 pb-3 mb-0 fw-bold">Top active pages</h5>
                            <ul class="list-unstyled">
                                <li class="d-flex justify-content-between pb-1 pt-1"><small>/product/readypro/index.html</small> <span>7</span></li>
                                <li class="d-flex justify-content-between pb-1 pt-1"><small>/product/kaiadmin/demo.html</small> <span>10</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> -->

    <div class="row">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header">
            <div class="card-title">Pendaftar Terbaru</div>
          </div>
          <div class="card-body p-0">
            <div class="table-responsive">
              <!-- Projects table -->
              <table class="table align-items-center mb-0">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">Nama</th>
                    <th scope="col">Email</th>
                    <th scope="col">Telp</th>
                    <th scope="col">Tanggal</th>
                  </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $userTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <tr>
                    <th scope="row"><?php echo e($siswa->name); ?></th>
                    <td><?php echo e($siswa->email); ?></td>
                    <td><?php echo e($siswa->telp ?? '-'); ?></td>
                    <td>
                      <i class="fas fa-arrow-up text-success me-3"></i>
                     <?php echo e($siswa->created_at); ?>

                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
    </div>

    

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('ppdb.admin.layout.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NewPPDB\resources\views/ppdb/admin/pertanyaan/dashboard.blade.php ENDPATH**/ ?>