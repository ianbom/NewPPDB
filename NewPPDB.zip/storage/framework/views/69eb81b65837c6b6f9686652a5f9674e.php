<?php $__env->startSection('content'); ?>
<div class="page-inner">
    <div class="page-header">
        <h3 class="fw-bold mb-3">Data Siswa</h3>
        <ul class="breadcrumbs mb-3">
            <li class="nav-home">
                <a href="#">
                    <i class="bi bi-person"></i>
                </a>
            </li>
            <li class="separator">
                <i class="bi bi-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Tables</a>
            </li>
            <li class="separator">
                <i class="bi bi-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Data Siswa</a>
            </li>
        </ul>
    </div>
    <div class="row">
        <?php if(session('success')): ?>
        <div class="alert alert-info alert-dismissible alert-label-icon rounded-label fade show" role="alert">
            <i class="ri-checkbox-circle-line label-icon"></i>
            <strong>Sukses</strong> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible alert-label-icon rounded-label fade show" role="alert">
            <i class="ri-checkbox-circle-line label-icon"></i>
            <strong>Error</strong> <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Daftar Siswa</h4>
                </div>
                <div class="card-body">

                    <div class="d-flex align-items-center mb-3">
                        <form action="<?php echo e(route('siswa.genratePdf')); ?>" method="GET" class="d-flex align-items-center">
                            <select name="status_id" class="form-select w-auto me-2" required>
                                <option value="">Pilih Status</option>
                                <option value="">Belum Verifikasi</option>
                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($st->id); ?>"><?php echo e(ucfirst($st->tipe)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="submit" class="btn btn-danger btn-sm">
                                <i class="bi bi-file-earmark-pdf"></i> Export PDF
                            </button>
                        </form>
                    </div>

                    <form id="bulkUpdateForm" action="<?php echo e(route('siswa.bulkUpdateStatus')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="d-flex align-items-center mb-3">
                            <select name="status_id" class="form-select w-auto me-2" required>
                                <option value="">Pilih Status Baru</option>
                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($st->id); ?>"><?php echo e(ucfirst($st->tipe)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="submit" class="btn btn-sm btn-primary" onclick="return confirm('Apakah Anda yakin ingin mengubah status siswa yang dipilih?')">
                                <i class="bi bi-arrow-repeat"></i> Update Status
                            </button>
                        </div>

                        <div class="table-responsive">
                            <table id="basic-datatables" class="table table-striped table-hover">
                                <thead class="">
                                    <tr>
                                        <th class="text-center"><input type="checkbox" id="selectAll"></th>
                                        <th>ID</th>
                                        <th>Nama</th>
                                        <th>Email</th>
                                        <th>No HP</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><input type="checkbox" name="selected_ids[]" value="<?php echo e($s->id); ?>"></td>
                                        <td><?php echo e($s->id); ?></td>
                                        <td><?php echo e($s->name); ?></td>
                                        <td><?php echo e($s->email); ?></td>
                                        <td><?php echo e($s->telp ?? '-'); ?></td>
                                        <td>
                                            <?php if($s->status && $s->status->tipe == 'verifikasi'): ?>
                                                <span class="badge text-white bg-info">Verifikasi</span>
                                            <?php elseif($s->status && $s->status->tipe == 'administrasi'): ?>
                                                <span class="badge text-white bg-primary">Administrasi</span>
                                            <?php elseif($s->status && $s->status->tipe == 'lolos'): ?>
                                                <span class="badge text-white bg-success">Lulus</span>
                                            <?php elseif($s->status && $s->status->tipe == 'ditolak'): ?>
                                                <span class="badge text-white bg-danger">Gagal</span>
                                            <?php else: ?>
                                                <span class="badge text-white bg-secondary">Belum Verifikasi</span>
                                            <?php endif; ?>
                                        </td>

                                        <td>
                                            <a href="<?php echo e(route('siswa.show', $s->id)); ?>" class="btn btn-warning btn-sm">
                                                <i class="bi bi-eye"></i> Detail
                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function () {
    $("#basic-datatables").DataTable({
        "lengthMenu": [[10, 25, 50, 100, -1], [10, 25, 50, 100, "Semua"]],
        "pageLength": 10 // Default jumlah data yang ditampilkan
    });

    // Select All Checkbox
    $("#selectAll").click(function () {
        $("input[name='selected_ids[]']").prop("checked", this.checked);
    });
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ppdb.admin.layout.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NewPPDB\resources\views/ppdb/admin/siswa/index_siswa.blade.php ENDPATH**/ ?>