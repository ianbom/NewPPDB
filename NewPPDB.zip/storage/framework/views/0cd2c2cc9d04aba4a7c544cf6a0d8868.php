<?php $__env->startSection('content'); ?>
<div class="page-inner">
    <div class="page-header">
        <h3 class="fw-bold mb-3">Daftar Pertanyaan</h3>
        <ul class="breadcrumbs mb-3">
            <li class="nav-home">
                <a href="#">
                    <i class="bi bi-archive"></i>
                </a>
            </li>
            <li class="separator">
                <i class="bi bi-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Tables</a>
            </li>
            <li class="separator">
                <i class="bi bi-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Data Pertanyaan</a>
            </li>
        </ul>
    </div>

    <div class="card">
        <?php if(session('success')): ?>
        <div class="alert alert-info alert-dismissible alert-label-icon rounded-label fade show" role="alert">
            <i class="ri-checkbox-circle-line label-icon"></i>
            <strong>Sukses</strong> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible alert-label-icon rounded-label fade show" role="alert">
            <i class="ri-checkbox-circle-line label-icon"></i>
            <strong>Error</strong> <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="card-body">
            <div class="table-responsive">
                <table id="basic-datatables" class="table table-bordered table-striped">
                    <thead class="">
                        <tr>
                            <th>No</th>
                            <th>Pertanyaan</th>
                            <th>Status Jawaban</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pertanyaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($item->pertanyaan); ?></td>
                            <td>
                                <?php if(isset($jawaban[$item->id])): ?>
                                    <span class="badge bg-success">Sudah dijawab</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Belum dijawab</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(isset($jawaban[$item->id])): ?>
                                    <a href="<?php echo e(route('pemberkasan.edit', $jawaban[$item->id])); ?>" class="btn btn-outline-secondary btn-sm">Edit</a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('pemberkasan.show', $item->id)); ?>" class="btn btn-primary btn-sm">Jawab</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
      $("#basic-datatables").DataTable({});
    });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ppdb.user.layout.user_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NewPPDB\resources\views/ppdb/user/pemberkasan/index_pemberkasan.blade.php ENDPATH**/ ?>