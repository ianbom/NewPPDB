<?php $__env->startSection('content'); ?>

<div class="page-inner">
    <div class="page-header">
        <h3 class="fw-bold mb-3">Edit Pertanyaan</h3>
        <ul class="breadcrumbs mb-3">
            <li class="nav-home">
                <a href="#">
                    <i class="bi bi-archive"></i>
                </a>
            </li>
            <li class="separator">
                <i class="bi bi-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Pemberkasan</a>
            </li>
            <li class="separator">
                <i class="bi bi-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Edit Pertanyaan</a>
            </li>
        </ul>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Form Edit Jawaban Pemberkasan</div>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('pemberkasan.update', $jawaban->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <!-- Hidden input untuk pertanyaan_id -->
                        <input type="hidden" name="pertanyaan_id" value="<?php echo e($jawaban->pertanyaan_id); ?>">

                        <div class="form-group">
                            <label for="pertanyaan">Pertanyaan</label>
                            <p class="fw-bold"><?php echo e($jawaban->pertanyaan->pertanyaan); ?></p>
                        </div>

                        <div class="form-group">
                            <label for="jawaban">Jawaban Anda</label>

                            <?php if($jawaban->pertanyaan->tipe == 'text'): ?>
                                <input type="text" class="form-control" name="jawaban" value="<?php echo e($jawaban->jawaban); ?>" required>

                            <?php elseif($jawaban->pertanyaan->tipe == 'date'): ?>
                                <input type="date" class="form-control" name="jawaban" value="<?php echo e($jawaban->jawaban); ?>" required>

                            <?php elseif($jawaban->pertanyaan->tipe == 'file'): ?>
                                <input type="file" class="form-control" name="jawaban">
                                <?php if($jawaban->jawaban): ?>
                                    <p class="mt-2">File saat ini: <a href="<?php echo e(asset('storage/' . $jawaban->jawaban)); ?>" target="_blank">Lihat Berkas</a></p>
                                <?php endif; ?>

                            <?php elseif($jawaban->pertanyaan->tipe == 'radio'): ?>
                                <?php $__currentLoopData = ['A', 'B', 'C', 'D', 'E']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $opsiKey = 'opsi_' . $opsi; ?>
                                    <?php if(!empty($jawaban->pertanyaan->$opsiKey)): ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="jawaban" value="<?php echo e($jawaban->pertanyaan->$opsiKey); ?>" <?php echo e($jawaban->jawaban == $jawaban->pertanyaan->$opsiKey ? 'checked' : ''); ?> required>
                                            <label class="form-check-label"><?php echo e($jawaban->pertanyaan->$opsiKey); ?></label>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php elseif($jawaban->pertanyaan->tipe == 'checkbox'): ?>
                                <?php $selectedJawaban = json_decode($jawaban->jawaban, true) ?? []; ?>
                                <?php $__currentLoopData = ['A', 'B', 'C', 'D', 'E']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $opsiKey = 'opsi_' . $opsi; ?>
                                    <?php if(!empty($jawaban->pertanyaan->$opsiKey)): ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="jawaban[]" value="<?php echo e($jawaban->pertanyaan->$opsiKey); ?>" <?php echo e(in_array($jawaban->pertanyaan->$opsiKey, $selectedJawaban) ? 'checked' : ''); ?>>
                                            <label class="form-check-label"><?php echo e($jawaban->pertanyaan->$opsiKey); ?></label>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary">Update Jawaban</button>
                        <a href="<?php echo e(route('pemberkasan.index')); ?>" class="btn btn-secondary">Batal</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('ppdb.user.layout.user_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NewPPDB\resources\views/ppdb/user/pemberkasan/edit_pemberkasan.blade.php ENDPATH**/ ?>