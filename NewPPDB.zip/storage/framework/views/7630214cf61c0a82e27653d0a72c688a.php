<?php $__env->startSection('content'); ?>
<div class="page-inner">
    <div class="page-header">
        <h3 class="fw-bold mb-3">Edit Status</h3>
        <ul class="breadcrumbs mb-3">
            <li class="nav-home">
                <a href="#">
                    <i class="icon-home"></i>
                </a>
            </li>
            <li class="separator">
                <i class="icon-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Status</a>
            </li>
            <li class="separator">
                <i class="icon-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Edit Status</a>
            </li>
        </ul>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Form Edit Status</div>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('status.update', $status->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group">
                            <label for="tipe">Tipe Status</label>
                            <select class="form-control" name="tipe" id="tipe" required>
                                <option value="verifikasi" <?php echo e($status->tipe == 'verifikasi' ? 'selected' : ''); ?>>Verifikasi</option>
                                <option value="administrasi" <?php echo e($status->tipe == 'administrasi' ? 'selected' : ''); ?>>Administrasi</option>
                                <option value="lolos" <?php echo e($status->tipe == 'lolos' ? 'selected' : ''); ?>>Lolos</option>
                                <option value="ditolak" <?php echo e($status->tipe == 'ditolak' ? 'selected' : ''); ?>>Ditolak</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="judul">Judul</label>
                            <input type="text" class="form-control" name="judul" id="judul" value="<?php echo e($status->judul); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <textarea class="form-control" name="deskripsi" id="deskripsi" rows="3" required><?php echo e($status->deskripsi); ?></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
                        <a href="<?php echo e(route('status.index')); ?>" class="btn btn-secondary">Batal</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ppdb.admin.layout.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NewPPDB\resources\views/ppdb/admin/status/edit_status.blade.php ENDPATH**/ ?>