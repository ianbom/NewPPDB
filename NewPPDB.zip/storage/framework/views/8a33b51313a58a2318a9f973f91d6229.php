<!-- Sidebar -->

<style>
    .sidebar {
    color: white !important;
}

.sidebar a {
    color: white !important;
}

.sidebar a:hover {
    color: #ddd !important; /* Warna hover agar lebih soft */
}

.text-section {
    color: white !important;
}
</style>

<div class="sidebar"style="background: linear-gradient(to bottom, #172c18, #0a650d)">
    <div class="sidebar-logo">
      <!-- Logo Header -->
      <div class="logo-header">
        <a href="#" class="logo">
          <img
            src="<?php echo e(asset('logo-None-iain-madura-f1a016af.jpg')); ?>"
            alt="navbar brand"
            class="navbar-brand"
            height="50"
          />
        </a>
        <div class="nav-toggle">
          <button class="btn btn-toggle toggle-sidebar">
            <i class="gg-menu-right"></i>
          </button>
          <button class="btn btn-toggle sidenav-toggler">
            <i class="gg-menu-left"></i>
          </button>
        </div>
        <button class="topbar-toggler more">
          <i class="gg-more-vertical-alt"></i>
        </button>
      </div>
      <!-- End Logo Header -->
    </div>
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
      <div class="sidebar-content">
        <ul class="nav nav-secondary">
          <li class="nav-item">
            <a
             href="<?php echo e(route('profile.index')); ?>"
            >
              <i class="bi bi-person-square"></i>
              <p >Profile</p>

            </a>

          </li>
          <li class="nav-section">
            <span class="sidebar-mini-icon">
              <i class="fa fa-ellipsis-h"></i>
            </span>
            <h4 class="text-section">Data</h4>
          </li>

          <li class="nav-item">
            <a href="<?php echo e(route('pemberkasan.index')); ?>">
                <i class="bi bi-file-text-fill"></i>
              <p>Pemberkasan</p>

            </a>
          </li>

          <li class="nav-item">
            <a href="<?php echo e(route('pengumuman.index')); ?>">
                <i class="bi bi-megaphone-fill"></i>
              <p>Pengumuman</p>
             
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <!-- End Sidebar -->
<?php /**PATH C:\laragon\www\NewPPDB\resources\views/ppdb/user/layout/sidebar.blade.php ENDPATH**/ ?>