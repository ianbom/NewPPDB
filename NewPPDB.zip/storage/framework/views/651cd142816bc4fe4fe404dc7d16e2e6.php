<?php $__env->startSection('content'); ?>
<style>
    .ppdb-login {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9f5ec 100%);
        min-height: 100vh;
    }

    .ppdb-info {
        background: linear-gradient(135deg, #2e7d32 0%, #1b5e20 100%);
        padding: 4rem;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
        justify-content: center;
    }

    .ppdb-card {
        border-radius: 15px;
        border: none;
        max-width: 500px;
        margin: 0 auto;
    }

    .ppdb-card .card-header {
        border-radius: 15px 15px 0 0;
        padding: 1.5rem;
        font-size: 1.5rem;
    }

    .school-logo img {
        max-width: 150px;
        margin-bottom: 2rem;
    }

    .school-features .feature-item {
        display: flex;
        align-items: center;
        margin-bottom: 1.5rem;
        color: #fff;
    }

    .school-features .feature-item i {
        font-size: 1.5rem;
        width: 40px;
        color: #c8e6c9;
    }

    .input-group-text {
        border-radius: 8px 0 0 8px !important;
        border: none !important;
    }

    .form-control {
        border-radius: 0 8px 8px 0 !important;
        padding: 12px 15px;
        border: 1px solid #dee2e6;
    }

    .btn-success {
        background-color: #2e7d32;
        border: none;
        padding: 12px;
        transition: all 0.3s ease;
    }

    .btn-success:hover {
        background-color: #1b5e20;
        transform: translateY(-2px);
    }
</style>

<div class="ppdb-login">
    <div class="container-fluid">
        <div class="row align-items-center min-vh-100">
            <div class="col-md-6 ppdb-info d-none d-md-block">
                <div class="school-logo mb-4">
                    <img src="<?php echo e(asset('logo-None-iain-madura-f1a016af.jpg')); ?>" alt="School Logo" class="img-fluid">
                </div>
                <h1 class="text-white mb-3">PMB IAIN MADURAN</h1>
                <p class="lead text-white">Tahun Ajaran 2025/2026</p>
                <div class="school-features mt-5">
                    <div class="feature-item">
                        <i class="bi bi-mortarboard-fill"></i>
                        <span>Sekolah Berbasis Karakter</span>
                    </div>
                    <div class="feature-item">
                        <i class="bi bi-book"></i>
                        <span>Kurikulum Merdeka Belajar</span>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <div class="card ppdb-card shadow-lg">
                    <div class="card-header bg-success text-white">
                        <h3 class="mb-0"><i class="fas fa-key"></i> Reset Password</h3>
                    </div>

                    <div class="card-body p-4">
                        <form method="POST" action="<?php echo e(route('password.update')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="token" value="<?php echo e($token); ?>">

                            <div class="mb-4">
                                <div class="input-group">
                                    <span class="input-group-text bg-success text-white">
                                        <i class="fas fa-envelope"></i>
                                    </span>
                                    <input id="email" type="email"
                                           class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="email" value="<?php echo e($email ?? old('email')); ?>"
                                           placeholder="Alamat Email" required>
                                </div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-4">
                                <div class="input-group">
                                    <span class="input-group-text bg-success text-white">
                                        <i class="fas fa-lock"></i>
                                    </span>
                                    <input id="password" type="password"
                                           class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="password" placeholder="Password Baru" required>
                                </div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-4">
                                <div class="input-group">
                                    <span class="input-group-text bg-success text-white">
                                        <i class="fas fa-lock"></i>
                                    </span>
                                    <input id="password-confirm" type="password" class="form-control"
                                           name="password_confirmation" placeholder="Konfirmasi Password Baru" required>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-success btn-lg w-100 mb-3">
                                <i class="fas fa-key"></i> Reset Password
                            </button>

                            <div class="text-center pt-3">
                                <a href="<?php echo e(route('login')); ?>" class="text-success">
                                    <i class="fas fa-arrow-left"></i> Kembali ke Halaman Login
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NewPPDB\resources\views/auth/passwords/reset.blade.php ENDPATH**/ ?>