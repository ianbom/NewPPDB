<?php $__env->startSection('content'); ?>
<div class="page-inner">
    <div class="page-header d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-3">Data Siswa</h3>


        <a href="<?php echo e(route('siswa.index')); ?>" class="btn btn-outline-primary">
            <i class="bi bi-arrow-left me-2"></i>Kembali
        </a>
    </div>

    <div class="row g-4">

        <?php if(session('success')): ?>
        <div class="alert alert-info alert-dismissible alert-label-icon rounded-label fade show" role="alert">
            <i class="ri-checkbox-circle-line label-icon"></i>
            <strong>Sukses</strong> <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible alert-label-icon rounded-label fade show" role="alert">
            <i class="ri-checkbox-circle-line label-icon"></i>
            <strong>Error</strong> <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <!-- Profile Card -->
        <div class="col-md-4">
            <div class="card border-0 shadow-sm">
                <div class="card-body text-center p-4">
                    <div class="position-relative mb-4 d-flex justify-content-center">
                        <?php if($siswa->profile ): ?>
                            <img src="<?php echo e(asset('storage/' . $siswa->profile)); ?>"
                                 class="img-fluid border border-2 border-dark shadow"
                                 width="180" height="180"
                                 alt="<?php echo e($siswa->name); ?>">
                        <?php else: ?>
                            <div class="rounded-circle border border-4 border-white shadow d-flex align-items-center justify-content-center bg-light mx-auto" style="width: 180px; height: 180px;">
                                <i class="bi bi-person-circle text-secondary" style="font-size: 100px; line-height: 1;"></i>
                            </div>
                        <?php endif; ?>
                        <span class="position-absolute bottom-0 end-0 p-2 bg-success rounded-circle" style="transform: translate(-50%, -50%);">
                            <i class="bi bi-check-circle text-white"></i>
                        </span>
                    </div>
                    <h3 class="fw-bold mb-1"><?php echo e($siswa->name); ?></h3>
                    <p class="text-muted mb-3">
                        <i class="bi bi-envelope me-2"></i><?php echo e($siswa->email); ?>

                    </p>
                    <div class="d-flex justify-content-center gap-3 mb-3">
                        <div class="px-3 py-2 bg-light rounded-3">
                            <i class="bi bi-telephone me-2"></i><?php echo e($siswa->telp ?? '-'); ?>

                        </div>
                        <div class="px-3 py-2 bg-light rounded-3">
                            <i class="bi bi-person-badge me-2"></i>Status Seleksi: <?php echo e($siswa->status->tipe ?? 'Belum verifikasi'); ?>

                        </div>
                    </div>

                    <!-- Form Ubah Status -->
                    <form action="<?php echo e(route('siswa.update', $siswa->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label for="status_id" class="form-label fw-bold">Ubah Status</label>
                            <select name="status_id" id="status_id" class="form-select">
                                <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($stat->id); ?>" <?php echo e($siswa->status_id == $stat->id ? 'selected' : ''); ?>>
                                        <?php echo e($stat->tipe); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-save me-2"></i>Simpan Perubahan
                        </button>
                    </form>

                    <br>
                    <a href="<?php echo e(route('siswa.editPassword', $siswa->id)); ?>" class="btn btn-secondary w-100"> Ubah Password</a>

                </div>
            </div>
        </div>

        <!-- Pemberkasan Card -->
        <div class="col-md-8">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white py-3">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="card-title mb-0 fw-bold">
                            <i class="bi bi-file-earmark-text me-2"></i>Pemberkasan
                        </h4>
                        <span class="badge bg-primary rounded-pill">
                            <?php echo e($pertanyaan->count()); ?> Berkas
                        </span>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table id="basic-datatables" class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="px-4">#</th>
                                    <th>Pertanyaan</th>
                                    <th>Jawaban</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pertanyaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pertanyaanItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $jawabanSiswa = $siswa->jawaban->firstWhere('pertanyaan_id', $pertanyaanItem->id);
                                    ?>
                                    <tr>
                                        <td class="px-4"><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($pertanyaanItem->pertanyaan); ?></td>
                                        <td>
                                            <?php if($jawabanSiswa): ?>
                                                <?php if(Str::startsWith($jawabanSiswa->jawaban, 'siswa/berkas/')): ?>
                                                    <a href="<?php echo e(asset('storage/' . $jawabanSiswa->jawaban)); ?>"
                                                       target="_blank"
                                                       class="btn btn-sm btn-outline-primary">
                                                        <i class="bi bi-file-earmark-pdf me-2"></i>Lihat Berkas
                                                    </a>
                                                <?php else: ?>
                                                    <span class="">
                                                       <?php echo e($jawabanSiswa->jawaban); ?>

                                                    </span>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <span class="text-danger">
                                                    <i class="bi bi-x-circle me-2"></i>Belum Dijawab
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
$(document).ready(function () {
    $("#basic-datatables").DataTable({
    });

});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ppdb.admin.layout.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NewPPDB\resources\views/ppdb/admin/siswa/show_siswa.blade.php ENDPATH**/ ?>