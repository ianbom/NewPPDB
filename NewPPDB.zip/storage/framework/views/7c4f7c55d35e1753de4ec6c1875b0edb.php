<?php $__env->startSection('content'); ?>

<div class="page-inner">
    <div class="page-header">
        <h3 class="fw-bold mb-3">Input Pemberkasan</h3>
        <ul class="breadcrumbs mb-3">
            <li class="nav-home">
                <a href="#">
                    <i class="bi bi-archive"></i>
                </a>
            </li>
            <li class="separator">
                <i class="bi bi-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Pemberkasan</a>
            </li>
            <li class="separator">
                <i class="bi bi-arrow-right"></i>
            </li>
            <li class="nav-item">
                <a href="#">Input Data</a>
            </li>
        </ul>
    </div>

    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <div class="card-title">Form Jawaban Pemberkasan</div>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('pemberkasan.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="pertanyaan_id" value="<?php echo e($pemberkasan->id); ?>">

                        <div class="form-group">
                            <label for="pertanyaan">Pertanyaan</label>
                            <p><strong><?php echo e($pemberkasan->pertanyaan); ?></strong></p>
                        </div>

                        <div class="form-group">
                            <label for="jawaban">Jawaban Anda</label>

                            <?php if($pemberkasan->tipe == 'text'): ?>
                                <input type="text" class="form-control" name="jawaban" required>

                            <?php elseif($pemberkasan->tipe == 'date'): ?>
                                <input type="date" class="form-control" name="jawaban" required>

                            <?php elseif($pemberkasan->tipe == 'file'): ?>
                                <input type="file" class="form-control" name="jawaban" required>

                            <?php elseif($pemberkasan->tipe == 'radio'): ?>
                                <?php $__currentLoopData = ['A', 'B', 'C', 'D', 'E']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $opsiKey = 'opsi_' . $opsi; ?>
                                    <?php if(!empty($pemberkasan->$opsiKey)): ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="jawaban" value="<?php echo e($pemberkasan->$opsiKey); ?>" required>
                                            <label class="form-check-label"><?php echo e($pemberkasan->$opsiKey); ?></label>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php elseif($pemberkasan->tipe == 'checkbox'): ?>
                                <?php $__currentLoopData = ['A', 'B', 'C', 'D', 'E']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $opsiKey = 'opsi_' . $opsi; ?>
                                    <?php if(!empty($pemberkasan->$opsiKey)): ?>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="jawaban[]" value="<?php echo e($pemberkasan->$opsiKey); ?>">
                                            <label class="form-check-label"><?php echo e($pemberkasan->$opsiKey); ?></label>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>

                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?php echo e(route('pemberkasan.index')); ?>" class="btn btn-secondary">Batal</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('ppdb.user.layout.user_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\NewPPDB\resources\views/ppdb/user/pemberkasan/create_pemberkasan.blade.php ENDPATH**/ ?>